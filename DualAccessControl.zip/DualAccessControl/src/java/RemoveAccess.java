/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.sql.*;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.Security;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import de.flexiprovider.core.FlexiCoreProvider;
import java.util.Random;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpSession;

/**
 *
 * @author GOWTHAM
 */
public class RemoveAccess extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
     private String algo="AES/ECB/PKCS5Padding";
     
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       // PrintWriter out = response.getWriter();
       
            String filSelect = request.getParameter("filSelect");
            
           
            String originalName = filSelect;
            String primary = null;
            //String seckey="";
            RequestDispatcher rd;
            //int count = 0;
            Object obj;
            int i=0;
            byte[] block = new byte[8];
            String email2="";
            
            HttpSession sn = request.getSession(true);
   //  sn.setAttribute("username",username);
     // System.out.println(""+username2+","+filSelect);
           try { 
            Class.forName("com.mysql.jdbc.Driver").newInstance();
           Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/sedasc","root","password");
           
          
                String query = "select * from uploadlist where fileid='" + filSelect +"'"; 
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(query);
            if (rs.next()) {
       
        String query1 = "delete from uploadlist where fileid = ?";
      PreparedStatement preparedStmt = con.prepareStatement(query1);
      preparedStmt.setString(1, filSelect);

      // execute the preparedstatement
      preparedStmt.execute();
      
       rd = request.getRequestDispatcher("updatesuccess.jsp");
                rd.forward(request, response);

            }
            else
            {
                
             
                 rd = request.getRequestDispatcher("updatefailure.jsp");
                rd.forward(request, response);
               
              
            }
           

        }  
        catch (Exception ex) {
            System.out.print(ex);
        }
        finally {
           // out.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    public static String getMimeType(String fileUrl)throws java.io.IOException, MalformedURLException 
  {
    String type = null;
    URL u = new URL(fileUrl);
    URLConnection uc = null;
    uc = u.openConnection();
    type = uc.getContentType();
    return type;
  }
}
