/*
SQLyog - Free MySQL GUI v5.13
Host - 5.0.22-community-nt : Database - sedasc
*********************************************************************
Server version : 5.0.22-community-nt
*/

SET NAMES utf8;

SET SQL_MODE='';

create database if not exists `sedasc`;

USE `sedasc`;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

/*Table structure for table `ownerdetails` */

DROP TABLE IF EXISTS `ownerdetails`;

CREATE TABLE `ownerdetails` (
  `fullname` varchar(50) default NULL,
  `username` varchar(50) NOT NULL default '',
  `password` varchar(50) default NULL,
  `prof` varchar(50) default NULL,
  `mobile` varchar(50) default NULL,
  `emailid` varchar(50) default NULL,
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ownerdetails` */

insert into `ownerdetails` (`fullname`,`username`,`password`,`prof`,`mobile`,`emailid`) values ('Pavithra','pavi','pavi','Student','8523145698','pavithra@gmail.com');

/*Table structure for table `servertable` */

DROP TABLE IF EXISTS `servertable`;

CREATE TABLE `servertable` (
  `username` varchar(50) default NULL,
  `password` varchar(50) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `servertable` */

insert into `servertable` (`username`,`password`) values ('cloudserver','cloudserver');

/*Table structure for table `uploadlist` */

DROP TABLE IF EXISTS `uploadlist`;

CREATE TABLE `uploadlist` (
  `fileid` int(50) NOT NULL auto_increment,
  `ownername` varchar(50) default NULL,
  `filename` varchar(200) default NULL,
  `receiver` varchar(50) default NULL,
  `key1` varchar(50) default NULL,
  `key2` varchar(50) default NULL,
  `status` varchar(50) default NULL,
  `status1` varchar(50) default NULL,
  PRIMARY KEY  (`fileid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `uploadlist` */

insert into `uploadlist` (`fileid`,`ownername`,`filename`,`receiver`,`key1`,`key2`,`status`,`status1`) values (1,'pavi','output.txt','selva','107OJFND','24SQkvbu','approved','approved');

/*Table structure for table `userdetails` */

DROP TABLE IF EXISTS `userdetails`;

CREATE TABLE `userdetails` (
  `fullname` varchar(50) default NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) default NULL,
  `prof` varchar(50) default NULL,
  `mobile` varchar(50) default NULL,
  `emailid` varchar(50) default NULL,
  PRIMARY KEY  (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `userdetails` */

insert into `userdetails` (`fullname`,`username`,`password`,`prof`,`mobile`,`emailid`) values ('Selva Kumar','selva','java','Student','9003570191','dselvait@gmail.com');

SET SQL_MODE=@OLD_SQL_MODE;